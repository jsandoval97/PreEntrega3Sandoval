from setuptools import setup, find_packages

setup(
    name='paquete1',
    version='1.0',
    packages=find_packages(),
    description='Este paquete contiene la clase cliente, y fue creado para el curso de python flex de CoderHouse',
    author='JSandoval',
    author_email='jcsandlesc@gmail.com',
)
